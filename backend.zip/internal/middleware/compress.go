package middleware

import (
	"compress/gzip"
	"io"
	"strings"
	"sync"

	"github.com/gin-gonic/gin"
)

var gzipPool = sync.Pool{
	New: func() interface{} {
		w, _ := gzip.NewWriterLevel(nil, gzip.DefaultCompression)
		return w
	},
}

type gzipWriter struct {
	gin.ResponseWriter
	writer *gzip.Writer
}

func (g *gzipWriter) Write(data []byte) (int, error) {
	return g.writer.Write(data)
}

func (g *gzipWriter) WriteString(s string) (int, error) {
	return g.writer.Write([]byte(s))
}

// Gzip compresses JSON responses for bandwidth savings (~70% reduction)
func Gzip() gin.HandlerFunc {
	return func(c *gin.Context) {
		// Skip gzip for WebSocket upgrade requests — the response writer wrapper
		// breaks gorilla/websocket's Hijack() call for the 101 Switching Protocols handshake.
		if strings.EqualFold(c.GetHeader("Upgrade"), "websocket") {
			c.Next()
			return
		}
		if !strings.Contains(c.GetHeader("Accept-Encoding"), "gzip") {
			c.Next()
			return
		}

		gz := gzipPool.Get().(*gzip.Writer)
		defer gzipPool.Put(gz)
		gz.Reset(c.Writer)

		c.Header("Content-Encoding", "gzip")
		c.Header("Vary", "Accept-Encoding")
		c.Writer = &gzipWriter{ResponseWriter: c.Writer, writer: gz}

		c.Next()

		// Must close before response is sent
		gz.Close()
		// Remove Content-Length since it's now compressed
		c.Header("Content-Length", "")
	}
}

// Ensure gzipWriter implements io.Writer
var _ io.Writer = (*gzipWriter)(nil)
